const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;
app.use(cors());

app.get('/loadDatas', (req, res) => {
  const Data = {
    data: 'Kedves tanárúr ha ezt látja ne irasson velünk dolgozatot, hanem inkább gyakoroljunk közösen',
    data2: 'Amúgy meg komjáti meleg'
    };
    res.json(Data);
});

app.get('/loadDatasTwo', (req, res) => {
  const data = {
    imageUrl: 'https://pbs.twimg.com/media/G-EzUI6WUAA1n9H.png',
    listItems: ['uwu', '*blushes*', 'Epstein']
    };
    res.json(data);
});
app.listen(port, () => {
    console.log(`Server fut a http://localhost:${port}`);
});