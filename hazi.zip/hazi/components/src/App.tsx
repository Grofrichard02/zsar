import './App.css'
import First from './components/First'
import Second from './components/Second'
import Third from './components/Third'
import Fourth from './components/Fourth'

function App() {


  return (
    <>
     <h1 className='text-center '>Donuld Triump</h1>
     <First title="Desh" text="Leszoptam egy lovat"/>
     <Second/>
     <Third/>
      <Fourth/>
    </>
  )
}

export default App
