import {useState} from "react"
import reactDefLogo from "../assets/react.svg"

function Second(){
    const [shown, setShown] = useState(false)

    function ShowP():void {
        setShown(true)
    }

    function HideP():void{
        setShown(false)
    }
    return(
        <section>
            <img  src={reactDefLogo} className={shown ? "" : "hidden"}/>
            <button onClick={ShowP}>Megjelenítés</button>
            <button onClick={HideP}>Eltűntetés</button>

        </section>
    )
}

export default Second;
